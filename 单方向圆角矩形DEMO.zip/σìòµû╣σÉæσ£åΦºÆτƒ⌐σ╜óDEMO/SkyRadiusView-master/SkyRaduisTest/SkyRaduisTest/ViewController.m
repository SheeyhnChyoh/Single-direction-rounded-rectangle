//
//  ViewController.m
//  SkyRaduisTest
//
//  Created by skytoup on 15/8/11.
//  Copyright (c) 2015年 skytoup. All rights reserved.
//

#import "ViewController.h"
#import "SkyRadiusView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    SkyRadiusView * skyra = [[SkyRadiusView alloc]initWithFrame:CGRectMake(50, 200, 76, 88)];
    [skyra setBackgroundColor:[UIColor clearColor]];
    skyra.bottomLeftRadius = YES;
    skyra.bottomRightRadius = YES;
    skyra.cornerRadius = 10;
//    skyra.borderWidth = 1;
//    skyra.borderColor = [UIColor redColor];
    skyra.backgroundColor = [UIColor greenColor];
    [self.view addSubview:skyra];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
